<?php

// DATOS DE CONEXION
define ('DBSERVER','127.0.0.1');
define ('DBNAME','peliculas');
define ('DBUSER','root');
define ('DBPASSWORD','');


    
// Definir otras constantes 