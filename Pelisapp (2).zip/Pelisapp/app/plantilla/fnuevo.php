<?php

// Guardo la salida en un buffer(en memoria)
// No se envia al navegador
ob_start();
?>
<center>
<div id='aviso'><b><?= (isset($msg))?$msg:"" ?></b></div>
<link href="web/css/form.css" rel="stylesheet" type="text/css" />


<form name='ALTA' enctype="multipart/form-data" method="POST" action="index.php?orden=Alta">
<table>
<tr><td>Nombre     :</td><td> <input type="text" name="nombre" value=""></td></tr>
<tr><td>director :</td><td> <input type="text" id="director" name="director" value=""></td></tr>
<tr><td>genero : </td><td><input type="text"    name="genero" value = "" ></td></tr>
<tr><td>imagen : </td><td><input type="file"    name="archivo" value = "" ></td></tr>
<tr><td>trailer : </td><td><input type="text"    name="trailer" value = "" ></td></tr>
</table>
<p class="clasificacion">
    <input id="radio1" type="radio" name="estrellas" value="5"><!--
    --><label for="radio1">★</label><!--
    --><input id="radio2" type="radio" name="estrellas" value="4"><!--
    --><label for="radio2">★</label><!--
    --><input id="radio3" type="radio" name="estrellas" value="3"><!--
    --><label for="radio3">★</label><!--
    --><input id="radio4" type="radio" name="estrellas" value="2"><!--
    --><label for="radio4">★</label><!--
    --><input id="radio5" type="radio" name="estrellas" value="1"><!--
    --><label for="radio5">★</label>
  </p>

<br>
	
	<input type="hidden" name="MAX_FILE_SIZE" value="100000" />
	<input class="buscar" type="submit" value="Almacenar">
	<input  class="buscar2" type="cancel" value="Cancelar" size="10" onclick="javascript:window.location='index.php'" >
</form>

</center>
<?php 
// Vacio el bufer y lo copio a contenido
// Para que se muestre en div de contenido
$contenido = ob_get_clean();
include_once "principal.php";

?>